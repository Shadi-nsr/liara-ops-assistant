"""Liara Ops Assistant: safe deployment, monitoring, and incident triage."""

__version__ = "0.1.0"

