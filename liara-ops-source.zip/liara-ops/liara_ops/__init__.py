"""Liara Ops Assistant: safe deployment, monitoring, and incident triage."""

__version__ = "0.2.0"
