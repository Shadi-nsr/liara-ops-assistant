from __future__ import annotations

from typing import List

from .client import LiaraClient
from .models import Finding, IncidentReport, Operation


class IncidentPlanner:
    """Rule-based incident planner with explicit evidence and safe actions."""

    def __init__(self, client: LiaraClient) -> None:
        self.client = client

    def diagnose(self, app: str, scenario: str) -> IncidentReport:
        metrics = self.client.metrics(app, scenario)
        findings: List[Finding] = []
        operations: List[Operation] = []
        if scenario == "healthy":
            findings.append(Finding("info", "HEALTHY", "سرویس پایدار است", [
                f"خطا {metrics.error_rate_pct}% و تأخیر p95 برابر {metrics.p95_latency_ms}ms است.",
                f"{metrics.replicas_ready}/{metrics.replicas_desired} نمونه آماده‌اند.",
            ], 0.99, ["پایش دوره‌ای را ادامه دهید."]))
        elif scenario == "high_error_rate":
            findings.append(Finding("high", "ERROR_BUDGET", "افزایش خطای پاسخ مشاهده شد", [
                f"نرخ خطا {metrics.error_rate_pct}% (آستانه هشدار: ۲٪).",
                f"p95 latency به {metrics.p95_latency_ms}ms رسیده است.",
            ], 0.96, ["ابتدا لاگ نسخه اخیر را بررسی کنید.", "در صورت تأیید ارتباط، rollback نسخه اخیر را آماده کنید."]))
            operations.append(Operation("rollback", app, {"reason": "high_error_rate", "target": "previous_stable"}, "high"))
        elif scenario == "crash_loop":
            findings.append(Finding("critical", "CRASH_LOOP", "یک نمونه در چرخه‌ی crash قرار دارد", [
                f"فقط {metrics.replicas_ready}/{metrics.replicas_desired} نمونه آماده است.",
                f"مصرف حافظه {metrics.memory_pct}% و نرخ خطا {metrics.error_rate_pct}% است.",
            ], 0.98, ["لاگ startup و مقدار متغیرهای محیطی را بررسی کنید.", "پس از بررسی، نمونه ناسالم را restart کنید."]))
            operations.append(Operation("restart", app, {"unhealthy_only": True, "reason": "crash_loop"}, "medium"))
        elif scenario == "oom":
            findings.append(Finding("critical", "OOM_PRESSURE", "فشار حافظه باعث ناپایداری شده است", [
                f"مصرف حافظه {metrics.memory_pct}% و CPU {metrics.cpu_pct}% است.",
                f"{metrics.replicas_ready}/{metrics.replicas_desired} نمونه آماده‌اند.",
            ], 0.95, ["محدودیت حافظه و آخرین release را بررسی کنید.", "برای کاهش ریسک، scale افقی را آماده کنید."]))
            operations.append(Operation("scale", app, {"replicas": metrics.replicas_desired + 1, "reason": "oom_pressure"}, "medium"))
        else:
            raise ValueError(f"scenario ناشناخته است: {scenario}")
        summary = findings[0].title + ". اقدام پیشنهادی قبل از اجرا نیازمند تأیید انسانی است."
        return IncidentReport(app, scenario, summary, findings, operations)

