from __future__ import annotations

import copy
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .models import DeploymentRequest, MetricSnapshot, Operation, now_iso


class SafetyError(RuntimeError):
    """Raised when a potentially destructive operation lacks approval."""


MAX_REPLICAS = 100
_PATH_SEGMENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
_DANGEROUS_OPERATIONS = {"deploy", "rollback", "restart", "scale"}


def _validate_path_segment(value: str, field_name: str) -> str:
    value = str(value or "").strip()
    if not value or not _PATH_SEGMENT.fullmatch(value):
        raise ValueError(
            f"{field_name} باید یک نام کوتاه بدون فاصله یا جداکننده‌ی مسیر باشد"
        )
    return value


def _validate_target(target: str, field_name: str, segments: int) -> str:
    parts = str(target or "").split("/")
    if len(parts) != segments:
        raise ValueError(f"{field_name} ساختار معتبری ندارد")
    return "/".join(_validate_path_segment(part, field_name) for part in parts)


@dataclass
class DryRunTransport:
    """In-memory Liara API seam. It never opens a socket or changes infrastructure."""

    calls: List[Dict[str, Any]] = field(default_factory=list)

    def request(self, method: str, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        # Keep the audit record immutable if the caller mutates its request
        # dictionary after this method returns.
        call = {
            "method": method,
            "path": path,
            "payload": copy.deepcopy(payload),
            "dry_run": True,
            "at": now_iso(),
        }
        self.calls.append(call)
        return {
            "ok": True,
            "dry_run": True,
            "message": "ثبت شد؛ هیچ درخواست شبکه‌ای ارسال نشد.",
            "request": call,
        }


class LiaraClient:
    """A deliberately safe client facade for the demo.

    The production adapter can implement the same methods using Liara's API. This
    challenge build only uses :class:`DryRunTransport` so it cannot mutate a real
    account, even when a user accidentally supplies production-looking arguments.
    """

    def __init__(self, transport: Optional[DryRunTransport] = None) -> None:
        self.transport = transport or DryRunTransport()

    def plan_deploy(self, request: DeploymentRequest) -> Operation:
        app = _validate_path_segment(request.app, "app")
        environment = _validate_path_segment(request.environment, "environment")
        if request.replicas < 1:
            raise ValueError("replicas باید حداقل ۱ باشد")
        if request.replicas > MAX_REPLICAS:
            raise ValueError(f"replicas نمی‌تواند بیشتر از {MAX_REPLICAS} باشد")
        if request.strategy not in {"rolling", "blue-green", "recreate"}:
            raise ValueError("strategy باید یکی از rolling، blue-green یا recreate باشد")
        parameters = request.as_dict()
        parameters["app"] = app
        parameters["environment"] = environment
        return Operation(
            kind="deploy",
            target=f"{app}/{environment}",
            parameters=parameters,
            risk="medium" if request.strategy != "recreate" else "high",
            requires_approval=True,
        )

    def deploy(self, operation: Operation, approved: bool = False) -> Dict[str, Any]:
        if operation.kind != "deploy":
            raise ValueError("deploy فقط operationای از نوع deploy را می‌پذیرد")
        _validate_target(operation.target, "target", 2)
        self._check(operation, approved)
        return self.transport.request("POST", f"/v1/apps/{operation.target}/deployments", operation.parameters)

    def metrics(self, app: str, scenario: str = "healthy") -> MetricSnapshot:
        app = _validate_path_segment(app, "app")
        samples = {
            "healthy": MetricSnapshot(app, 99.98, 0.08, 180, 31.0, 42.0, 2, 2),
            "high_error_rate": MetricSnapshot(app, 97.40, 7.80, 1_120, 58.0, 71.0, 2, 2),
            "crash_loop": MetricSnapshot(app, 84.20, 12.40, 2_850, 44.0, 93.0, 1, 2),
            "oom": MetricSnapshot(app, 91.10, 4.90, 1_980, 88.0, 96.0, 2, 3),
        }
        if scenario not in samples:
            raise ValueError(f"scenario ناشناخته است: {scenario}")
        return samples[scenario]

    def remediate(self, operation: Operation, approved: bool = False) -> Dict[str, Any]:
        paths = {
            "rollback": "/v1/apps/{}/deployments/rollback",
            "restart": "/v1/apps/{}/restart",
            "scale": "/v1/apps/{}/scale",
        }
        if operation.kind not in paths:
            raise ValueError(f"عملیات رفع‌اشکال پشتیبانی نمی‌شود: {operation.kind}")
        _validate_target(operation.target, "target", 1)
        self._check(operation, approved)
        return self.transport.request("POST", paths[operation.kind].format(operation.target), operation.parameters)

    @staticmethod
    def _check(operation: Operation, approved: bool) -> None:
        requires_approval = operation.requires_approval or operation.kind in _DANGEROUS_OPERATIONS
        if requires_approval and not approved:
            raise SafetyError(
                f"عملیات {operation.operation_id} نیاز به تأیید انسانی دارد؛ "
                "ابتدا plan را بررسی و با --approve اجرا کنید."
            )
