"""Small dependency-free browser surface for Liara Ops.

The CLI remains the primary interface.  This module exposes the same safe
facade through a local-only web page so a human can inspect evidence and click
the approval gate without copying JSON between terminal commands.
"""

from __future__ import annotations

import json
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from .client import DryRunTransport, LiaraClient
from .models import DeploymentRequest
from .planner import IncidentPlanner


WEB_PAGE = r"""<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Liara Ops Assistant</title>
<style>
:root{color-scheme:dark;font-family:ui-sans-serif,system-ui,-apple-system,sans-serif;background:#09111f;color:#e7edf7}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 85% 0,#18365c 0,#09111f 48%);min-height:100vh}
main{max-width:1120px;margin:auto;padding:36px 20px 56px}.top{display:flex;justify-content:space-between;gap:20px;align-items:start;margin-bottom:24px}.eyebrow{color:#8fb8ff;font-size:13px;letter-spacing:.08em}.top h1{margin:8px 0;font-size:36px}.top p{color:#aab8cd;max-width:690px;line-height:1.9}.badge{border:1px solid #315984;border-radius:999px;padding:9px 13px;color:#9bc5ff;white-space:nowrap;background:#0d1c31}
.grid{display:grid;grid-template-columns:360px 1fr;gap:18px}.panel{background:#101c2d;border:1px solid #233c5d;border-radius:18px;padding:20px;box-shadow:0 15px 45px #0003}.panel h2{margin:0 0 14px;font-size:20px}.field{display:grid;gap:7px;margin:12px 0}.field label{color:#aab8cd;font-size:13px}.field input,.field select{width:100%;padding:11px 12px;background:#0a1525;color:#e7edf7;border:1px solid #31557c;border-radius:9px;font:inherit}.buttons{display:flex;flex-wrap:wrap;gap:9px;margin-top:16px}.buttons button{border:0;border-radius:9px;padding:10px 13px;font:inherit;cursor:pointer;background:#1d416d;color:white}.buttons button.primary{background:#3878cb}.buttons button.danger{background:#8d3a4b}.buttons button:disabled{opacity:.45;cursor:not-allowed}.hint{font-size:12px;line-height:1.8;color:#93a9c4;margin:14px 0 0}.safety{margin-top:14px;padding:11px;border-radius:10px;background:#102d30;color:#8fe7d5;font-size:13px;line-height:1.8}.status{min-height:24px;color:#aab8cd;margin-bottom:10px}.output{background:#08111e;border:1px solid #233c5d;border-radius:12px;min-height:330px;padding:15px;overflow:auto;white-space:pre-wrap;direction:ltr;text-align:left;font:12px/1.65 ui-monospace,SFMono-Regular,Menlo,monospace}.summary{direction:rtl;text-align:right;padding:13px;background:#0e2236;border-radius:11px;line-height:1.9;margin-bottom:12px}.approve{display:none;margin-top:12px;padding:13px;border:1px solid #855a2e;border-radius:11px;background:#2e2110;color:#f5d49c;line-height:1.8}.approve button{margin-top:9px}.metric{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}.metric div{background:#0e2236;border-radius:10px;padding:10px}.metric b{display:block;font-size:18px;color:#b9d7ff}.metric span{font-size:11px;color:#8fa4bd}
@media(max-width:800px){.grid{grid-template-columns:1fr}.top{display:block}.badge{display:inline-block;margin-top:10px}.top h1{font-size:30px}.metric{grid-template-columns:repeat(2,1fr)}}
</style></head>
<body><main>
<section class="top"><div><div class="eyebrow">LIARA OPS ASSISTANT</div><h1>مشاهده، توضیح، تأیید</h1><p>داشبورد محلی برای پایش سرویس، تشخیص incident و آماده‌سازی اقدام. هر تغییر حساس ابتدا به شکل plan دیده می‌شود و فقط پس از تأیید شما به‌صورت <code>dry-run</code> ثبت می‌شود.</p></div><div class="badge">● آفلاین و امن</div></section>
<section class="grid"><aside class="panel"><h2>کنترل سناریو</h2>
<div class="field"><label for="app">نام سرویس</label><input id="app" value="checkout-api"></div>
<div class="field"><label for="scenario">سناریوی پایش</label><select id="scenario"><option value="healthy">healthy — پایدار</option><option value="high_error_rate">high_error_rate — خطای زیاد</option><option value="crash_loop">crash_loop — crash loop</option><option value="oom">oom — فشار حافظه</option></select></div>
<div class="buttons"><button class="primary" id="monitor">پایش متریک‌ها</button><button id="diagnose">تشخیص incident</button><button id="deploy">ساخت plan استقرار</button></div>
<div class="safety">هیچ سوکت شبکه‌ای باز نمی‌شود. مسیرهای rollback، restart، scale و deploy بدون تأیید اجرا نمی‌شوند.</div>
<p class="hint">برای شبیه‌سازی سناریوی پرخطا، ابتدا «تشخیص incident» را بزنید؛ سپس evidence و payload را ببینید و در صورت نیاز دکمه‌ی تأیید dry-run را انتخاب کنید.</p>
</aside><section class="panel"><div class="status" id="status">برای شروع یکی از عملیات را انتخاب کنید.</div><div id="summary"></div><div class="approve" id="approveBox">این اقدام هنوز اجرا نشده است و قبل از ثبت dry-run به تأیید انسانی نیاز دارد.<br><button class="danger" id="approve">تأیید و ثبت dry-run</button></div><pre class="output" id="output">—</pre></section></section>
</main>
<script>
const $=id=>document.getElementById(id), state={pending:null};
function show(data){$('output').textContent=JSON.stringify(data,null,2);$('summary').innerHTML='';}
async function request(path,options){const res=await fetch(path,options);const data=await res.json();if(!res.ok)throw new Error(data.error||'خطای ناشناخته');return data;}
function loading(text){$('status').textContent=text;$('approveBox').style.display='none';$('summary').innerHTML='';state.pending=null;}
async function monitor(){loading('در حال خواندن متریک‌ها…');try{const app=encodeURIComponent($('app').value.trim()),scenario=$('scenario').value;const data=await request(`/api/monitor?app=${app}&scenario=${scenario}`);show(data);const m=data.metrics;$('summary').innerHTML=`<div class="metric"><div><b>${m.error_rate_pct}%</b><span>نرخ خطا</span></div><div><b>${m.p95_latency_ms}ms</b><span>p95 latency</span></div><div><b>${m.memory_pct}%</b><span>حافظه</span></div><div><b>${m.replicas_ready}/${m.replicas_desired}</b><span>replica آماده</span></div></div>`;$('status').textContent='snapshot متریک با موفقیت خوانده شد.';}catch(e){$('status').textContent=e.message;show({ok:false,error:e.message});}}
async function diagnose(approve=false){loading(approve?'در حال ثبت dry-run…':'در حال جمع‌آوری evidence و ساخت plan…');try{const app=$('app').value.trim(),scenario=$('scenario').value;const data=await request('/api/diagnose',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({app,scenario,approve})});show(data);const report=data.report||{};$('summary').innerHTML=`<div class="summary"><b>${report.summary||'گزارش آماده است'}</b><br>${(report.findings||[]).map(f=>`شدت: ${f.severity} · اطمینان: ${f.confidence}<br>${(f.evidence||[]).join(' · ')}`).join('<br>')}</div>`;if(!approve&&report.operations&&report.operations.length){state.pending='diagnose';$('approveBox').style.display='block';$('status').textContent='plan آماده است؛ اجرای آن متوقف و منتظر تأیید است.';}else{$('status').textContent=approve?'dry-run ثبت شد؛ زیرساختی تغییر نکرد.':'سرویس سالم است و اقدام اصلاحی پیشنهاد نشد.';}}catch(e){$('status').textContent=e.message;show({ok:false,error:e.message});}}
async function deploy(approve=false){loading(approve?'در حال ثبت dry-run استقرار…':'در حال ساخت plan استقرار…');try{const data=await request('/api/deploy',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({app:$('app').value.trim(),approve})});show(data);if(!approve){state.pending='deploy';$('approveBox').style.display='block';$('status').textContent='plan استقرار آماده است؛ تأیید انسانی لازم است.';}else $('status').textContent='dry-run استقرار ثبت شد؛ زیرساختی تغییر نکرد.';}catch(e){$('status').textContent=e.message;show({ok:false,error:e.message});}}
$('monitor').onclick=monitor;$('diagnose').onclick=()=>diagnose(false);$('deploy').onclick=()=>deploy(false);$('approve').onclick=()=>state.pending==='deploy'?deploy(true):diagnose(true);
</script></body></html>"""


class WebHandler(BaseHTTPRequestHandler):
    client: LiaraClient
    transport: DryRunTransport

    def _json(self, payload: dict, status: int = HTTPStatus.OK) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
            return json.loads(self.rfile.read(length).decode("utf-8")) if length else {}
        except (ValueError, TypeError, UnicodeDecodeError, json.JSONDecodeError):
            return {}

    def do_GET(self) -> None:  # noqa: N802
        url = urlparse(self.path)
        if url.path == "/":
            body = WEB_PAGE.encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if url.path == "/api/monitor":
            params = parse_qs(url.query)
            app = params.get("app", [""])[0]
            scenario = params.get("scenario", ["healthy"])[0]
            try:
                return self._json({"phase": "monitor", "metrics": self.client.metrics(app, scenario).as_dict(), "dry_run": True})
            except (ValueError, TypeError) as exc:
                return self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        return self._json({"error": "مسیر پیدا نشد"}, HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        if self.path == "/api/diagnose":
            payload = self._body()
            try:
                app = str(payload.get("app", "")).strip()
                scenario = str(payload.get("scenario", "high_error_rate"))
                report = IncidentPlanner(self.client).diagnose(app, scenario)
                result = {"phase": "diagnose", "report": report.as_dict()}
                if payload.get("approve") and report.operations:
                    result["execution"] = self.client.remediate(report.operations[0], approved=True)
                result["audit"] = self.transport.calls
                return self._json(result)
            except (ValueError, TypeError) as exc:
                return self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        if self.path == "/api/deploy":
            payload = self._body()
            try:
                request = DeploymentRequest(
                    app=str(payload.get("app", "")).strip(),
                    environment=str(payload.get("environment", "production")),
                    branch=str(payload.get("branch", "main")),
                    image=payload.get("image"),
                    region=str(payload.get("region", "iran")),
                    strategy=str(payload.get("strategy", "rolling")),
                    replicas=int(payload.get("replicas", 2)),
                )
                operation = self.client.plan_deploy(request)
                result = {"phase": "plan", "operation": operation.as_dict()}
                if payload.get("approve"):
                    result["execution"] = self.client.deploy(operation, approved=True)
                result["audit"] = self.transport.calls
                return self._json(result)
            except (ValueError, TypeError) as exc:
                return self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        return self._json({"error": "مسیر پیدا نشد"}, HTTPStatus.NOT_FOUND)

    def log_message(self, *_args: object) -> None:
        return


def serve(host: str = "127.0.0.1", port: int = 8123) -> None:
    transport = DryRunTransport()
    WebHandler.transport = transport
    WebHandler.client = LiaraClient(transport)
    server = ThreadingHTTPServer((host, port), WebHandler)
    print(f"Liara Ops web UI running on http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

