from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict

from .client import DryRunTransport, LiaraClient, SafetyError
from .models import DeploymentRequest, Operation
from .planner import IncidentPlanner
from .web import serve


def emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="liara-ops", description="دستیار امن استقرار و رفع‌اشکال لیارا")
    sub = parser.add_subparsers(dest="command", required=True)

    deploy = sub.add_parser("deploy", help="ساخت plan استقرار و اجرای dry-run")
    deploy.add_argument("app")
    deploy.add_argument("--environment", default="production")
    deploy.add_argument("--branch", default="main")
    deploy.add_argument("--image")
    deploy.add_argument("--region", default="iran")
    deploy.add_argument("--strategy", choices=["rolling", "blue-green", "recreate"], default="rolling")
    deploy.add_argument("--replicas", type=int, default=2)
    deploy.add_argument("--approve", action="store_true", help="تأیید صریح اجرای عملیات")

    monitor = sub.add_parser("monitor", help="نمایش snapshot متریک‌های نمونه")
    monitor.add_argument("app")
    monitor.add_argument("--scenario", choices=["healthy", "high_error_rate", "crash_loop", "oom"], default="healthy")

    diagnose = sub.add_parser("diagnose", help="تشخیص incident و پیشنهاد action")
    diagnose.add_argument("app")
    diagnose.add_argument("--scenario", choices=["healthy", "high_error_rate", "crash_loop", "oom"], default="high_error_rate")
    diagnose.add_argument("--approve", action="store_true", help="اجرای dry-run action پیشنهادی")

    demo = sub.add_parser("demo", help="اجرای سناریوی کامل برای ویدئوی دمو")
    demo.add_argument("--app", default="checkout-api")

    web = sub.add_parser("web", help="اجرای رابط مرورگری محلی و امن")
    web.add_argument("--host", default="127.0.0.1")
    web.add_argument("--port", type=int, default=8123)
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    if args.command == "web":
        serve(args.host, args.port)
        return {"phase": "web", "host": args.host, "port": args.port}
    transport = DryRunTransport()
    client = LiaraClient(transport)
    if args.command == "deploy":
        req = DeploymentRequest(args.app, args.environment, args.branch, args.image, args.region, args.strategy, args.replicas)
        operation = client.plan_deploy(req)
        result: Dict[str, Any] = {"phase": "plan", "operation": operation.as_dict()}
        if args.approve:
            result["execution"] = client.deploy(operation, approved=True)
        else:
            result["next_step"] = "پس از بررسی، همین دستور را با --approve اجرا کنید."
        result["audit"] = transport.calls
        return result
    if args.command == "monitor":
        return {"phase": "monitor", "metrics": client.metrics(args.app, args.scenario).as_dict(), "dry_run": True}
    if args.command == "diagnose":
        report = IncidentPlanner(client).diagnose(args.app, args.scenario)
        result = {"phase": "diagnose", "report": report.as_dict()}
        if args.approve and report.operations:
            operation = report.operations[0]
            result["execution"] = client.remediate(operation, approved=True)
        elif report.operations:
            result["next_step"] = "پس از بررسی evidence، با --approve اجرای dry-run را تأیید کنید."
        return result
    if args.command == "demo":
        request = DeploymentRequest(args.app, branch="main", image="registry.example/checkout:2026.10.21", replicas=2)
        operation = client.plan_deploy(request)
        report = IncidentPlanner(client).diagnose(args.app, "high_error_rate")
        return {
            "product": "Liara Ops Assistant",
            "safety": "تمام درخواست‌ها dry-run هستند و عملیات حساس نیازمند تأیید انسانی است.",
            "deploy_plan": operation.as_dict(),
            "incident": report.as_dict(),
            "simulated_execution": client.deploy(operation, approved=True),
            "simulated_remediation": client.remediate(report.operations[0], approved=True),
            "audit": transport.calls,
        }
    raise ValueError(f"command ناشناخته است: {args.command}")


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        emit(run(args))
        return 0
    except (ValueError, SafetyError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
