from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
import uuid


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


@dataclass
class DeploymentRequest:
    app: str
    environment: str = "production"
    branch: str = "main"
    image: Optional[str] = None
    region: str = "iran"
    strategy: str = "rolling"
    replicas: int = 2

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Operation:
    kind: str
    target: str
    parameters: Dict[str, Any]
    risk: str
    requires_approval: bool = True
    operation_id: str = field(default_factory=lambda: "op_" + uuid.uuid4().hex[:10])
    created_at: str = field(default_factory=now_iso)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class MetricSnapshot:
    app: str
    uptime_pct: float
    error_rate_pct: float
    p95_latency_ms: int
    cpu_pct: float
    memory_pct: float
    replicas_ready: int
    replicas_desired: int
    captured_at: str = field(default_factory=now_iso)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Finding:
    severity: str
    code: str
    title: str
    evidence: List[str]
    confidence: float
    next_steps: List[str]

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class IncidentReport:
    app: str
    scenario: str
    summary: str
    findings: List[Finding]
    operations: List[Operation]
    generated_at: str = field(default_factory=now_iso)

    def as_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result["findings"] = [item.as_dict() for item in self.findings]
        result["operations"] = [item.as_dict() for item in self.operations]
        return result

