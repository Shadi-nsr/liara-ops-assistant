import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from liara_ops.client import DryRunTransport, LiaraClient, SafetyError
from liara_ops.models import DeploymentRequest
from liara_ops.planner import IncidentPlanner


class LiaraOpsTests(unittest.TestCase):
    def setUp(self):
        self.transport = DryRunTransport()
        self.client = LiaraClient(self.transport)

    def test_deploy_requires_approval(self):
        operation = self.client.plan_deploy(DeploymentRequest("shop-api"))
        with self.assertRaises(SafetyError):
            self.client.deploy(operation)
        self.assertEqual(self.transport.calls, [])

    def test_approved_deploy_is_dry_run_and_audited(self):
        operation = self.client.plan_deploy(DeploymentRequest("shop-api"))
        result = self.client.deploy(operation, approved=True)
        self.assertTrue(result["dry_run"])
        self.assertEqual(len(self.transport.calls), 1)
        self.assertEqual(self.transport.calls[0]["method"], "POST")

    def test_high_error_rate_produces_rollback(self):
        report = IncidentPlanner(self.client).diagnose("shop-api", "high_error_rate")
        self.assertEqual(report.findings[0].code, "ERROR_BUDGET")
        self.assertEqual(report.operations[0].kind, "rollback")

    def test_report_is_json_serializable(self):
        report = IncidentPlanner(self.client).diagnose("shop-api", "oom")
        json.dumps(report.as_dict(), ensure_ascii=False)
        self.assertEqual(report.operations[0].parameters["replicas"], 4)


if __name__ == "__main__":
    unittest.main()

