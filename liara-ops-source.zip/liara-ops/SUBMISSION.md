# متن پیشنهادی ارسال — Liara Ops Assistant

## ایده

`Liara Ops Assistant` یک دستیار عامل‌محور برای تیم‌های کوچک است که فاصله‌ی بین «دیدن هشدار» تا «اقدام مطمئن» را کوتاه می‌کند. کاربر به‌جای جست‌وجوی چند داشبورد، یک plan قابل فهم می‌گیرد: مشکل چیست، چه evidenceای آن را تأیید می‌کند، confidence چقدر است و کدام اقدام کم‌ریسک‌تر است.

## مسئله

وقتی خطا، crash loop یا فشار حافظه رخ می‌دهد، تصمیم عجولانه می‌تواند قطعی را بدتر کند. بسیاری از ابزارها یا فقط metric نشان می‌دهند یا مستقیماً تغییر ایجاد می‌کنند. Liara Ops بین این دو نقطه قرار می‌گیرد: ابتدا diagnose و plan، سپس human approval، و در این نمونه اجرای کاملاً dry-run برای حذف ریسک.

## تجربه‌ی نمونه

```text
کاربر: checkout-api خطای زیادی دارد.
عامل: نرخ خطا 7.8٪ و p95 برابر 1120ms است؛ confidence=0.96.
       پیشنهاد: rollback به previous_stable. شواهد و payload را ببینید.
کاربر: تأیید.
عامل: dry-run ثبت شد؛ هیچ درخواست شبکه‌ای ارسال نشد.
```

## تمایز

- safety gate انسانی پیش از هر `rollback`، `restart` یا `scale`؛
- evidence و confidence برای جلوگیری از توصیه‌های مبهم؛
- API facade قابل اتصال به Liara بدون گره‌زدن UI به provider؛
- audit log برای بازبینی تیم و postmortem؛
- CLI دمو که در کمتر از یک دقیقه قابل اجراست.

## وضعیت پیاده‌سازی

MVP در Python استاندارد، بدون dependency بیرونی، شامل مدل‌های typed، planner تشخیص incident، client امن، سناریوهای healthy/high-error/crash-loop/OOM، CLI و تست واحد است. تمام نمونه‌ها deterministic و آفلاین هستند.

